from  django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import Settings, settings

urlpatterns = [
    path("giriş", views.login_, name="log"),
    path("kayıt", views.register_, name="reg"),
    path("profil", views.profile, name="prof"),
    path("çıkış", views.exit, name="cik"),
    path("mlogin", views.mobileLogin, name="moblog"),
    path("mcomment/<slug:slug>", views.mobileComment, name="mobcom"),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) \
  + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

